===================================================
 SANDY WARFARE: RED vs BLUE (v1.0)
===================================================

GAME MODES & TEAM SELECTION:
1. Mode Selection: Single Player vs Multiplayer
2. Team Selection: Choose BLUE TEAM or RED TEAM dynamically!

WEAPON LOADOUT (Keys 1, 2, 3):
- 1: M1911 Pistol
- 2: Glock 19
- 3: AK47 Assault Rifle

CONTROLS:
- W / A / S / D  : Move
- Mouse          : Aim / Shoot
- 1 / 2 / 3      : Switch Weapons
- Spacebar       : Jump
- R              : Reload
===================================================
