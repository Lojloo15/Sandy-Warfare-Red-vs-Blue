const $=id=>document.getElementById(id),V=(x,y,z)=>new THREE.Vector3(x,y,z);
$('srv').value=location.protocol.startsWith('http')?location.host:'localhost:3000';
const H=(x,z)=>Math.sin(x*.05)*1.6+Math.cos(z*.04)*1.4+Math.sin((x+z)*.02)*2;
const scene=new THREE.Scene();scene.background=new THREE.Color(0xeed3a0);scene.fog=new THREE.Fog(0xeed3a0,40,200);
const cam=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.1,300);scene.add(cam);
const ren=new THREE.WebGLRenderer({antialias:true});ren.setSize(innerWidth,innerHeight);ren.setPixelRatio(Math.min(devicePixelRatio,2));ren.shadowMap.enabled=true;document.body.prepend(ren.domElement);
addEventListener('resize',()=>{cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();ren.setSize(innerWidth,innerHeight)});
scene.add(new THREE.HemisphereLight(0xfff2cc,0xb08a50,.75));
const sun=new THREE.DirectionalLight(0xfff0d0,1);sun.position.set(60,100,40);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-100,right:100,top:100,bottom:-100,far:300});scene.add(sun);
// ground
const gg=new THREE.PlaneGeometry(500,500,160,160);gg.rotateX(-Math.PI/2);const pos=gg.attributes.position,col=[];
for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i);pos.setY(i,H(x,z));const n=.9+.1*Math.sin(x*.9)*Math.cos(z*.7)+.06*Math.sin(x*.13+z*.2);col.push(.86*n,.7*n,.42*n)}
gg.setAttribute('color',new THREE.Float32BufferAttribute(col,3));gg.computeVertexNormals();
const ground=new THREE.Mesh(gg,new THREE.MeshStandardMaterial({vertexColors:true,roughness:1}));ground.receiveShadow=true;scene.add(ground);
// map
const solids=[];let seed=7;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
function box(x,z,w,h,d,c){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h+2,d),new THREE.MeshStandardMaterial({color:c,roughness:.9}));
 m.position.set(x,H(x,z)+h/2-1,z);m.castShadow=m.receiveShadow=true;m.userData.bb={x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2};scene.add(m);solids.push(m)}
function building(x,z){const c=0xc9a66b;box(x,z-8,16,5,1.2,c);box(x-8,z,1.2,5,16,c);box(x+8,z,1.2,5,16,c);box(x-5,z+8,6,5,1.2,c);box(x+5,z+8,6,5,1.2,c);box(x,z,3,3,3,0x9c7a46)}
[[0,0],[-38,10],[38,-10],[-22,-32],[26,32]].forEach(p=>building(...p));
for(let i=0;i<34;i++){const x=(rnd()-.5)*160,z=(rnd()-.5)*100,s=1.5+rnd()*2.5;box(x,z,s,s,s,rnd()<.5?0x8a6a3a:0x6d7a55)}
box(0,-88,180,6,2,0xb48f55);box(0,88,180,6,2,0xb48f55);box(-88,0,2,6,180,0xb48f55);box(88,0,2,6,180,0xb48f55);
for(const [z,c] of [[-76,0xd83030],[76,0x2f6fe0]]){box(-8,z,.6,6,.6,c);box(8,z,.6,6,.6,c);box(0,z,16.6,.6,.6,c)}
function push(p,r){for(const s of solids){const b=s.userData.bb;if(p.x>b.x0-r&&p.x<b.x1+r&&p.z>b.z0-r&&p.z<b.z1+r){
 const a=[p.x-(b.x0-r),b.x1+r-p.x,p.z-(b.z0-r),b.z1+r-p.z],m=Math.min(...a);
 if(m==a[0])p.x=b.x0-r;else if(m==a[1])p.x=b.x1+r;else if(m==a[2])p.z=b.z0-r;else p.z=b.z1+r}}}
// weapons
const W=[{n:'M1911',dmg:35,rate:.32,mag:7,auto:0,sp:.004,rl:1.5},{n:'Glock 19',dmg:22,rate:.13,mag:15,auto:0,sp:.008,rl:1.4},{n:'AK-47',dmg:30,rate:.1,mag:30,auto:1,sp:.014,rl:2.3}];
W.forEach(w=>w.ammo=w.mag);
function gunModel(i){const g=new THREE.Group(),m=(w,h,d,x,y,z,c)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color:c,metalness:.6,roughness:.4}));o.position.set(x,y,z);g.add(o)};
 if(i==0){m(.05,.06,.28,0,0,0,0x999999);m(.045,.13,.06,0,-.09,.08,0x3a2a1a);m(.03,.02,.02,0,.04,-.12,0x111111)}
 if(i==1){m(.05,.07,.26,0,0,0,0x222222);m(.045,.13,.06,0,-.1,.07,0x222222)}
 if(i==2){m(.06,.08,.6,0,0,-.05,0x2a2a2a);m(.03,.03,.35,0,.01,-.55,0x111111);m(.055,.07,.28,0,-.01,-.3,0x6b3f1d);m(.06,.1,.3,0,-.03,.3,0x6b3f1d);m(.04,.2,.07,0,-.14,-.02,0x222222);m(.04,.1,.05,0,-.1,.14,0x222222)}
 g.position.set(.22,-.2,-.45);g.visible=false;return g}
const guns=W.map((_,i)=>{const g=gunModel(i);cam.add(g);return g});
// actors
const actors=[];let me,mode,ws,myId,started=false,over=false,score=[0,0];
function mk(team,name){const a={team,name,hp:100,alive:true,yaw:0,cd:1,st:0,sd:1},g=new THREE.Group(),c=team?0x2f6fe0:0xd83030;
 const p=(w,h,d,x,y,z,col,head)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color:col}));o.position.set(x,y,z);o.castShadow=true;o.userData.a=a;if(head)o.userData.head=1;g.add(o)};
 p(.6,.8,.35,0,1.15,0,c);p(.25,.7,.25,-.17,.35,0,0x333333);p(.25,.7,.25,.17,.35,0,0x333333);p(.22,.22,.22,0,1.7,0,0xe0b48a,1);p(.2,.2,.2,0,1.78,0,c,1);p(.1,.12,.7,.3,1.2,-.4,0x222222);
 a.g=g;scene.add(g);actors.push(a);return a}
function spawn(a){a.alive=true;a.hp=100;const z=a.team?70:-70;a.g.position.set((Math.random()-.5)*50,0,z);a.g.position.y=H(a.g.position.x,z);a.g.visible=a!==me;a.yaw=a.team?0:Math.PI;a.g.rotation.y=a.yaw;
 if(a===me){me.vy=0;W.forEach(w=>w.ammo=w.mag);yaw=a.yaw;pitch=0}}
let yaw=0,pitch=0,fire=false,pull=false,cw=0,reloadT=0,lastShot=0;const keys={};
function begin(m,team){mode=m;if(started)return;started=true;me=mk(team,'You');me.vy=0;actors.length=0;actors.push(me);spawn(me);
 if(!m){const n=['Alpha','Bravo','Charlie','Delta','Echo'];for(let t=0;t<2;t++)for(let i=0;i<(t==team?4:5);i++){const b=mk(t,n[i]);b.bot=1;spawn(b);b.g.position.x=-30+i*15}}
 $('menu').style.display='none';$('hud').style.display='block';sw(0)}
function sw(i){cw=i;guns.forEach((g,j)=>g.visible=j==i);reloadT=0}
function reload(){const w=W[cw];if(reloadT<=0&&w.ammo<w.mag)reloadT=w.rl}
const spread=(d,s)=>{d=d.clone();d.x+=(Math.random()-.5)*s*2;d.y+=(Math.random()-.5)*s*2;d.z+=(Math.random()-.5)*s*2;return d.normalize()};
function tracer(a,b){const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints([a,b]),new THREE.LineBasicMaterial({color:0xffe080}));scene.add(l);setTimeout(()=>scene.remove(l),50)}
function fireRay(a,o,d,dmg){const t=solids.concat(actors.filter(x=>x!==a&&x.alive).map(x=>x.g));const h=new THREE.Raycaster(o,d,0,200).intersectObjects(t,true)[0];
 tracer(a===me?o.clone().add(V(0,-.15,0)).addScaledVector(d,1):o,h?h.point:o.clone().addScaledVector(d,100));
 if(h&&h.object.userData.a){const v=h.object.userData.a;if(v.team!==a.team)damage(v,dmg*(h.object.userData.head?2:1),a)}}
function damage(v,d,by){if(!v.alive)return;if(v.remote){ws.send(JSON.stringify({t:'hit',to:v.id,dmg:d}));if(by===me)flashMsg('Hit!',300);return}
 v.hp-=d;if(v===me){$('flash').style.opacity=.5;setTimeout(()=>$('flash').style.opacity=0,200)}if(v.hp<=0)die(v,by)}
function die(v,by){v.alive=false;v.g.visible=false;score[by.team]++;if(by===me)flashMsg('You eliminated '+v.name,1500);
 if(v===me){flashMsg('You were eliminated. Respawning...',2500);if(ws)ws.send(JSON.stringify({t:'dead',kt:by.team}))}
 setTimeout(()=>{if(!v.remote)spawn(v)},3000);if(score[by.team]>=30&&!mode&&!over){over=1;flashMsg((by.team?'BLUE':'RED')+' TEAM WINS!',4000);setTimeout(()=>location.reload(),4500)}}
let mt;function flashMsg(t,ms){$('msg').textContent=t;clearTimeout(mt);mt=setTimeout(()=>$('msg').textContent='',ms)}
function bot(b,dt){if(!b.alive)return;let t=null,bd=1e9;const p=b.g.position;
 for(const e of actors){if(e.team===b.team||!e.alive)continue;const d=e.g.position.distanceTo(p);if(d<bd){bd=d;t=e}}
 let mx=0,mf=0;b.st-=dt;if(b.st<0){b.sd=Math.random()<.5?-1:1;b.st=1+Math.random()*2}
 if(t){const dx=t.g.position.x-p.x,dz=t.g.position.z-p.z;let df=Math.atan2(-dx,-dz)-b.yaw;df=Math.atan2(Math.sin(df),Math.cos(df));b.yaw+=df*Math.min(1,dt*5);
  const eye=V(p.x,p.y+1.6,p.z),te=t.g.position.clone();te.y+=1.3;const dir=te.clone().sub(eye).normalize();
  const los=!new THREE.Raycaster(eye,dir,0,bd).intersectObjects(solids)[0];
  if(bd>(los?28:2))mf=1;mx=los?(bd<60?b.sd*.6:0):b.sd*.9;b.cd-=dt;
  if(los&&bd<80&&b.cd<=0&&Math.abs(df)<.25){b.cd=.25+Math.random()*.4;fireRay(b,eye,spread(dir,.03+bd*.0004),12)}}
 const f=V(-Math.sin(b.yaw),0,-Math.cos(b.yaw)),r=V(Math.cos(b.yaw),0,-Math.sin(b.yaw));
 p.addScaledVector(f,mf*5*dt).addScaledVector(r,mx*5*dt);p.x=Math.max(-85,Math.min(85,p.x));p.z=Math.max(-85,Math.min(85,p.z));push(p,.5);p.y=H(p.x,p.z);b.g.rotation.y=b.yaw}
function update(dt){const now=performance.now()/1000;
 if(me.alive){const sp=keys.ShiftLeft?10:6.5,f=(keys.KeyW?1:0)-(keys.KeyS?1:0),s=(keys.KeyD?1:0)-(keys.KeyA?1:0),p=me.g.position;
  const fw=V(-Math.sin(yaw),0,-Math.cos(yaw)),rt=V(Math.cos(yaw),0,-Math.sin(yaw)),mv=fw.multiplyScalar(f).add(rt.multiplyScalar(s));if(mv.length())mv.normalize();
  p.addScaledVector(mv,sp*dt);p.x=Math.max(-85,Math.min(85,p.x));p.z=Math.max(-85,Math.min(85,p.z));push(p,.5);
  const gy=H(p.x,p.z);me.vy-=25*dt;p.y+=me.vy*dt;if(p.y<=gy){p.y=gy;me.vy=0;if(keys.Space)me.vy=8}
  const w=W[cw];if(reloadT>0){reloadT-=dt;if(reloadT<=0)w.ammo=w.mag}
  if((w.auto?fire:pull)&&reloadT<=0&&now-lastShot>w.rate){if(w.ammo>0){lastShot=now;w.ammo--;const o=V(p.x,p.y+1.7,p.z),d=V(-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch));
   fireRay(me,o,spread(d,w.sp),w.dmg);guns[cw].position.z=-.35;cam.rotation.x+=.01}else reload()}
  pull=false;guns[cw].position.z+=(-.45-guns[cw].position.z)*Math.min(1,dt*15)}
 cam.position.set(me.g.position.x,me.g.position.y+1.7,me.g.position.z);cam.rotation.set(pitch,yaw,0,'YXZ');me.g.rotation.y=yaw;
 actors.forEach(a=>{if(a.bot)bot(a,dt)});
 if(ws&&ws.readyState==1&&now-(update.ls||0)>.066){update.ls=now;const p=me.g.position;ws.send(JSON.stringify({t:'s',x:p.x,y:p.y,z:p.z,ry:yaw}))}
 const w=W[cw];$('hp').textContent='HP '+Math.max(0,Math.ceil(me.hp));$('ammo').textContent=w.n+'  '+(reloadT>0?'RELOADING':w.ammo+' / '+w.mag);
 $('sc').innerHTML='<span style="color:#ff5050">RED '+score[0]+'</span> &nbsp;-&nbsp; <span style="color:#6aa0ff">'+score[1]+' BLUE</span>'}
// multiplayer
function connect(){try{ws=new WebSocket('ws://'+$('srv').value)}catch(e){return alert('Bad address')}
 ws.onerror=()=>{if(!started)alert('Cannot reach server. Start it with: npm start')};
 ws.onmessage=e=>{const m=JSON.parse(e.data),by=()=>actors.find(a=>a.id===m.id);
  if(m.t=='init'){myId=m.id;begin(1,m.team);m.players.forEach(add)}else if(m.t=='join')add(m);
  else if(m.t=='leave'){const a=by();if(a){scene.remove(a.g);actors.splice(actors.indexOf(a),1)}}
  else if(m.t=='s'){const a=by();if(a&&a.alive){a.g.position.set(m.x,m.y,m.z);a.g.rotation.y=m.ry}}
  else if(m.t=='hit'&&m.to==myId){damage(me,m.dmg,by()||{team:1-me.team})}
  else if(m.t=='dead'){score[m.kt]++;const a=by();if(a){a.alive=false;a.g.visible=false;setTimeout(()=>{a.alive=true;a.g.visible=true},3000)}}}}
function add(p){const a=mk(p.team,'P'+p.id);a.remote=1;a.id=p.id;a.g.position.set(p.x||0,p.y||0,p.z||0)}
// input
const cv=ren.domElement;$('pause').onclick=()=>cv.requestPointerLock();
document.addEventListener('pointerlockchange',()=>{$('pause').style.display=started&&document.pointerLockElement!==cv?'flex':'none'});
addEventListener('mousemove',e=>{if(document.pointerLockElement===cv){yaw-=e.movementX*.0022;pitch=Math.max(-1.5,Math.min(1.5,pitch-e.movementY*.0022))}});
addEventListener('mousedown',e=>{if(document.pointerLockElement===cv){fire=true;pull=true}});addEventListener('mouseup',()=>fire=false);
addEventListener('keydown',e=>{keys[e.code]=1;if(e.code=='KeyR')reload();if(/^Digit[123]$/.test(e.code))sw(+e.code[5]-1)});addEventListener('keyup',e=>keys[e.code]=0);
// start menu clicks need pointer lock too
document.querySelectorAll('#menu button').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>started&&cv.requestPointerLock(),50)));
let last=performance.now();(function loop(){requestAnimationFrame(loop);const n=performance.now(),dt=Math.min(.05,(n-last)/1000);last=n;if(started)update(dt);ren.render(scene,cam)})();
