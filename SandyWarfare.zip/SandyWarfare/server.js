// Sandy Warfare multiplayer server: run "npm install" then "npm start"
const http=require('http'),fs=require('fs'),path=require('path'),{WebSocketServer}=require('ws');
const types={'.html':'text/html','.js':'text/javascript'};
const srv=http.createServer((q,r)=>{const f=path.join(__dirname,q.url=='/'?'index.html':q.url.split('?')[0]);
 if(!['index.html','game.js'].includes(path.basename(f)))return r.writeHead(404).end();
 fs.readFile(f,(e,d)=>e?r.writeHead(404).end():r.writeHead(200,{'Content-Type':types[path.extname(f)]}).end(d))});
const wss=new WebSocketServer({server:srv});let nid=1;const P=new Map();
wss.on('connection',ws=>{const id=nid++,c=[0,0];P.forEach(p=>c[p.team]++);const team=c[0]<=c[1]?0:1;
 P.set(ws,{id,team,x:0,y:0,z:team?70:-70});
 ws.send(JSON.stringify({t:'init',id,team,players:[...P.values()].filter(p=>p.id!=id)}));
 wss.clients.forEach(o=>o!==ws&&o.send(JSON.stringify({t:'join',id,team})));
 ws.on('message',d=>{let m;try{m=JSON.parse(d)}catch{return}m.id=id;const s=JSON.stringify(m);wss.clients.forEach(o=>o!==ws&&o.readyState==1&&o.send(s))});
 ws.on('close',()=>{P.delete(ws);wss.clients.forEach(o=>o.send(JSON.stringify({t:'leave',id})))})});
srv.listen(3000,()=>console.log('Sandy Warfare server on http://localhost:3000'));
