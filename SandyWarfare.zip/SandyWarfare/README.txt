SANDY WARFARE: RED VS BLUE

SINGLE PLAYER (vs AI bots)
  Double-click index.html (Chrome/Edge/Firefox). Needs internet once per load for the three.js library.

MULTIPLAYER (online / LAN)
  1. Install Node.js (nodejs.org)
  2. In this folder run:  npm install   then   npm start
  3. Everyone opens http://YOUR-IP:3000 and clicks Multiplayer. Teams auto-balance.
  (For play over the internet, forward port 3000 on your router.)

CONTROLS
  WASD move, Shift sprint, Space jump, Mouse aim/shoot, R reload, 1 M1911, 2 Glock 19, 3 AK-47
